"use client"

import React from 'react'
import LeadStageMasterPage from '../components/LeadStageMasterPage/LeadStageMasterPage'

const page = () => {
    return (
        <div>
            <LeadStageMasterPage />
        </div>
    )
}

export default page
