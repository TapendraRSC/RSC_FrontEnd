"use client"

import React from 'react'
import StatusMasterView from '../components/StatusMasterView/StatusMasterView'

const page = () => {
    return (
        <div>
            <StatusMasterView />
        </div>
    )
}

export default page
