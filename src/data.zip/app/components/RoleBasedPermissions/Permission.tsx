'use client';
import React, { useEffect, useState } from 'react';
import { ChevronDown, Check } from 'lucide-react';
import { useDispatch, useSelector } from 'react-redux';
import { AppDispatch, RootState } from '../../../../store/store';
import { fetchPermissions } from '../../../../store/permissionSlice';
import { fetchPages } from '../../../../store/pagePermissionSlice';
import { getRoles } from '../../../../store/roleSlice';
import { setRolePermissions, fetchRolePermissions } from '../../../../store/rolePermissionSlice';
import { toast } from 'react-toastify';
import { fetchRolePermissionsSidebar } from '../../../../store/sidebarPermissionSlice';

interface Permission {
    pageName: string;
    permissions: {
        [key: string]: boolean;
    };
}

const UserPermissions: React.FC = () => {
    const dispatch = useDispatch<AppDispatch>();
    const { list, loading, error } = useSelector((state: RootState) => state.permissions);
    const { list: pages, loading: pagesLoading, error: pagesError } = useSelector((state: RootState) => state.pages);
    const { roles, loading: rolesLoading } = useSelector((state: RootState) => state.roles);

    const { rolePermissions, loading: rolePermissionsLoading } = useSelector((state: RootState) => state.rolePermissions);

    const [selectedRole, setSelectedRole] = useState<{ id: number; roleType: string }>({ id: 0, roleType: 'Select a role' });
    const [isDropdownOpen, setIsDropdownOpen] = useState<boolean>(false);
    const [permissions, setPermissions] = useState<Permission[]>([]);

    useEffect(() => {
        dispatch(fetchPermissions({ page: 1, limit: 100, searchValue: "" }));
        dispatch(fetchPages({ page: 1, limit: 100, searchValue: "" }));
        dispatch(getRoles({ page: 1, limit: 100, searchValue: "" }));
    }, [dispatch]);

    useEffect(() => {
        if (Array.isArray(pages?.data?.data) && pages.data.data.length) {
            const normalized = pages.data.data.map((p: any) => {
                const permissionsObj: { [key: string]: boolean } = {};

                if (list?.data?.data) {
                    list.data.permissions.forEach((permission: any) => {
                        permissionsObj[permission.id.toString()] = false;
                    });
                }

                if (rolePermissions?.permissions && selectedRole.id !== 0) {
                    const pagePermission = rolePermissions.permissions.find((rp: any) => rp.pageId === p.id);

                    if (pagePermission && pagePermission.permissionIds) {
                        pagePermission.permissionIds.forEach((permissionId: number) => {
                            permissionsObj[permissionId.toString()] = true;
                        });
                    }
                }

                return {
                    pageName: p.pageName ?? 'Unnamed Page',
                    permissions: permissionsObj,
                };
            });
            setPermissions(normalized);
        }
    }, [pages?.data?.data, list?.data?.permissions, rolePermissions, selectedRole.id]);
    // }, [pages?.data?.permissions, list?.data?.permissions, rolePermissions, selectedRole.id]);


    const handleRoleSelection = (role: any) => {
        setSelectedRole({ id: role.id, roleType: role.roleType });
        setIsDropdownOpen(false);

        if (role.id !== 0) {
            dispatch(fetchRolePermissions(role.id));
        } else {
            setPermissions(prevPermissions =>
                prevPermissions.map(p => ({
                    ...p,
                    permissions: Object.keys(p.permissions).reduce((acc, key) => {
                        acc[key] = false;
                        return acc;
                    }, {} as { [key: string]: boolean })
                }))
            );
        }
    };

    const togglePermission = (rowIdx: number, permissionId: string) => {
        setPermissions(prevPermissions => {
            const updated = [...prevPermissions];
            if (!updated[rowIdx]) return prevPermissions;
            const currentVal = updated[rowIdx].permissions?.[permissionId] ?? false;
            updated[rowIdx] = {
                ...updated[rowIdx],
                permissions: {
                    ...updated[rowIdx].permissions,
                    [permissionId]: !currentVal,
                },
            };
            return updated;
        });
    };

    const handleSaveChanges = async () => {
        if (selectedRole.id === 0) {
            alert('Please select a role first!');
            return;
        }

        const rolePermissionData: any = {
            roleId: selectedRole.id,
            permissions: permissions.map(permission => ({
                pageId: pages?.data.data.find((p: any) => p.pageName === permission.pageName)?.id,
                permissionIds: Object.keys(permission.permissions)
                    .filter(permissionId => permission.permissions[permissionId])
                    .map(permissionId => parseInt(permissionId)),
            })),
        };

        await dispatch(setRolePermissions(rolePermissionData))
            .unwrap()
            .then(async () => {
                toast.success('Permissions saved successfully!');
                await dispatch(fetchRolePermissions(selectedRole.id));

            })
            .catch((error) => {
                console.error('Failed to save permissions:', error);
                toast.error('Failed to save permissions.');
            });
    };

    const headers = list?.data?.permissions || [];

    return (
        <div className="w-full bg-white dark:bg-gray-900 shadow-xl rounded-xl overflow-hidden">
            <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 sm:px-6 py-4">
                <h2 className="text-lg sm:text-xl font-semibold">User Permissions</h2>
            </div>
            <div className="p-4 sm:p-6">
                {/* Role Dropdown */}
                <div className="relative mb-6">
                    <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Select Role</label>
                    <button
                        onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                        className="w-full sm:w-64 px-3 py-2 bg-white dark:bg-gray-800 border border-gray-300 dark:border-gray-700 rounded-lg flex justify-between items-center hover:border-indigo-400 transition-colors"
                    >
                        <span className="text-sm sm:text-base text-gray-900 dark:text-gray-200">{selectedRole.roleType}</span>
                        <ChevronDown className={`w-4 h-4 transition-transform ${isDropdownOpen ? 'rotate-180' : ''}`} />
                    </button>
                    {isDropdownOpen && (
                        <div className="absolute top-full left-0 w-full sm:w-64 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg z-20 mt-1">
                            {rolesLoading ? (
                                <div className="p-2 text-center text-gray-500 dark:text-gray-400">Loading roles...</div>
                            ) : (
                                roles?.map((role: any) => (
                                    <button
                                        key={role.id}
                                        onClick={() => handleRoleSelection(role)}
                                        className="block w-full text-left px-3 py-2 hover:bg-indigo-50 dark:hover:bg-gray-700 text-sm transition-colors text-gray-900 dark:text-gray-200"
                                    >
                                        {role.roleType}
                                    </button>
                                ))
                            )}
                        </div>
                    )}
                </div>

                {rolePermissionsLoading && (
                    <div className="mb-4 p-3 bg-orange-50 dark:bg-orange-900/30 border border-orange-200 dark:border-orange-700 rounded-lg">
                        <div className="flex items-center">
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-orange-600 mr-2"></div>
                            <span className="text-orange-700 dark:text-orange-300 text-sm">Loading permissions for {selectedRole.roleType}...</span>
                        </div>
                    </div>
                )}

                <div className="hidden xl:block">
                    <div className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
                        <div className="overflow-x-auto">
                            <table className="w-full min-w-full">
                                <thead>
                                    <tr className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700">
                                        <th className="text-left p-4 font-semibold text-gray-700 dark:text-gray-300 text-sm min-w-[180px]">Module Name</th>
                                        {headers?.map((h: any) => (
                                            <th key={h.id} className="text-center p-4 font-semibold text-gray-700 dark:text-gray-300 text-xs min-w-[80px] capitalize">
                                                {h.permissionName}
                                            </th>
                                        ))}
                                    </tr>
                                </thead>
                                <tbody>
                                    {loading || rolePermissionsLoading ? (
                                        <tr>
                                            <td colSpan={headers.length + 1} className="p-6 text-center text-gray-500 dark:text-gray-400">
                                                {rolePermissionsLoading ? 'Loading role permissions...' : 'Loading...'}
                                            </td>
                                        </tr>
                                    ) : error ? (
                                        <tr>
                                            <td colSpan={headers.length + 1} className="p-6 text-center text-red-500">{error}</td>
                                        </tr>
                                    ) : permissions.length > 0 ? (
                                        permissions?.map((row, ri) => (
                                            <tr key={ri} className={`border-b ${ri % 2 === 0 ? 'bg-white dark:bg-gray-900' : 'bg-gray-50/50 dark:bg-gray-800/50'} border-gray-200 dark:border-gray-700`}>
                                                <td className="p-4 text-gray-700 dark:text-gray-300 font-medium text-sm">{row.pageName}</td>
                                                {headers?.map((h: any) => {
                                                    const permissionId = h.id.toString();
                                                    const val = permissions[ri]?.permissions?.[permissionId] ?? false;
                                                    return (
                                                        <td key={h.id} className="p-4 text-center">
                                                            <button
                                                                onClick={() => togglePermission(ri, permissionId)}
                                                                disabled={rolePermissionsLoading}
                                                                className={`w-5 h-5 border-2 rounded flex items-center justify-center transition-all hover:scale-110 ${val
                                                                    ? 'bg-indigo-500 border-indigo-500 text-white shadow-md'
                                                                    : 'bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 hover:border-indigo-400'
                                                                    } ${rolePermissionsLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                                                            >
                                                                {val && <Check className="w-3 h-3" />}
                                                            </button>
                                                        </td>
                                                    );
                                                })}
                                            </tr>
                                        ))
                                    ) : (
                                        <tr>
                                            <td colSpan={headers.length + 1} className="p-6 text-center text-gray-500 dark:text-gray-400">No permissions to display.</td>
                                        </tr>
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                {/* TABLET VIEW */}
                <div className="hidden md:block xl:hidden">
                    <div className="border border-gray-200 dark:border-gray-700 rounded-lg overflow-hidden">
                        <div className="overflow-x-auto">
                            <div className={`min-w-[${Math.max(600, (headers.length + 2) * 80)}px]`}>
                                <div className="bg-gray-50 dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-4">
                                    <div className="grid gap-3" style={{ gridTemplateColumns: `200px repeat(${headers.length}, 80px)` }}>
                                        <div className="font-semibold text-gray-700 dark:text-gray-300 text-sm">Module Name</div>
                                        {headers.map((h: any) => (
                                            <div key={h.id} className="text-center font-semibold text-gray-700 dark:text-gray-300 text-xs capitalize">
                                                {h.permissionName}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                                {permissions?.map((row, ri) => (
                                    <div key={ri} className={`p-4 border-b ${ri % 2 === 0 ? 'bg-white dark:bg-gray-900' : 'bg-gray-50/50 dark:bg-gray-800/50'} border-gray-200 dark:border-gray-700`}>
                                        <div className="grid gap-3 items-center" style={{ gridTemplateColumns: `200px repeat(${headers.length}, 80px)` }}>
                                            <div className="text-gray-700 dark:text-gray-300 font-medium text-sm">{row.pageName}</div>
                                            {headers?.map((h: any) => {
                                                const permissionId = h.id.toString();
                                                const val = permissions[ri]?.permissions?.[permissionId] ?? false;
                                                return (
                                                    <div key={h.id} className="flex justify-center">
                                                        <button
                                                            onClick={() => togglePermission(ri, permissionId)}
                                                            disabled={rolePermissionsLoading}
                                                            className={`w-5 h-5 border-2 rounded flex items-center justify-center transition-all hover:scale-110 ${val
                                                                ? 'bg-indigo-500 border-indigo-500 text-white shadow-md'
                                                                : 'bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 hover:border-indigo-400'
                                                                } ${rolePermissionsLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                                                        >
                                                            {val && <Check className="w-3 h-3" />}
                                                        </button>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>

                {/* MOBILE VIEW */}
                <div className="block md:hidden space-y-4">
                    {permissions?.map((row, ri) => (
                        <div key={ri} className="border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 p-4 rounded-lg shadow-sm">
                            <h3 className="font-semibold text-gray-800 dark:text-gray-200 mb-4 text-base border-b border-gray-100 dark:border-gray-700 pb-2">{row.pageName}</h3>
                            <div className="grid grid-cols-2 gap-4">
                                {headers?.map((h: any) => {
                                    const permissionId = h.id.toString();
                                    const val = permissions[ri]?.permissions?.[permissionId] ?? false;
                                    return (
                                        <div key={h.id} className="flex items-center justify-between p-2 bg-gray-50 dark:bg-gray-800 rounded">
                                            <span className="text-sm text-gray-600 dark:text-gray-300 font-medium capitalize">{h.permissionName}</span>
                                            <button
                                                onClick={() => togglePermission(ri, permissionId)}
                                                disabled={rolePermissionsLoading}
                                                className={`w-5 h-5 border-2 rounded flex items-center justify-center transition-all hover:scale-110 ${val
                                                    ? 'bg-indigo-500 border-indigo-500 text-white shadow-md'
                                                    : 'bg-white dark:bg-gray-700 border-gray-300 dark:border-gray-600 hover:border-indigo-400'
                                                    } ${rolePermissionsLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                                            >
                                                {val && <Check className="w-3 h-3" />}
                                            </button>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    ))}
                </div>

                {/* Save Button */}
                <div className="mt-6 flex flex-col sm:flex-row gap-3 sm:justify-end">
                    <button
                        onClick={handleSaveChanges}
                        disabled={selectedRole.id === 0 || rolePermissionsLoading}
                        className={`w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-indigo-500 to-purple-600 text-white rounded-lg font-medium hover:from-indigo-600 hover:to-purple-700 transition-all shadow-md hover:shadow-lg ${(selectedRole.id === 0 || rolePermissionsLoading) ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                        Save Changes
                    </button>
                </div>
            </div>
        </div>
    );
};

export default UserPermissions;