"use client"

import React from 'react'
import ProjectStatus from '../components/ProjectStatus/ProjectStatus'

const page = () => {
    return (
        <div>
            <ProjectStatus />
        </div>
    )
}

export default page
