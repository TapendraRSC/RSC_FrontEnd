import React from 'react'
import LeadPlateform from '../components/LeadPlateform/LeadPlateform'

const page = () => {
    return (
        <div>
            <LeadPlateform />
        </div>
    )
}

export default page
