"use client"

import React from 'react'
import RolesPage from '../components/Roles/Roles'

const page = () => {
    return (
        <div>
            <RolesPage />
        </div>
    )
}

export default page
