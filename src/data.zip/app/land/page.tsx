import React from 'react'
import Land from '../components/Land/Land'

const page = () => {
    return (
        <div>
            <Land />
        </div>
    )
}

export default page
