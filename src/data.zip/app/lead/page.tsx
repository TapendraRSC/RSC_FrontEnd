import React from 'react'
import Lead from '../components/Lead/Lead'

const page = () => {
    return (
        <div>
            <Lead />
        </div>
    )
}

export default page
