import React from 'react'
import Booking from '../components/Booking/Booking'

const page = () => {
    return (
        <div>
            <Booking />
        </div>
    )
}

export default page
