"use client"

import React from 'react'
import PagePermission from '../components/PagePermission/PagePermission'

const page = () => {
    return (
        <div>
            <PagePermission />
        </div>
    )
}

export default page
