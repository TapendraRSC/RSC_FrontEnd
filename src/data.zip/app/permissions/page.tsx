"use client"

import React from 'react'
import PermissionsShow from '../components/Permissions/PermissionsShow'

const page = () => {
    return (
        <div>
            <PermissionsShow />
        </div>
    )
}

export default page
