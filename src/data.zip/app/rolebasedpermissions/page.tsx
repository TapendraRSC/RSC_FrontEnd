"use client"

import React from 'react'
import UserPermissions from '../components/RoleBasedPermissions/Permission'

const page = () => {
    return (
        <div>
            <UserPermissions />
        </div>
    )
}

export default page
