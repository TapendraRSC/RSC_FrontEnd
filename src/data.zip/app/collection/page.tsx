import React from 'react'
import Collection from '../components/Collection/Collection'

const page = () => {
    return (
        <div>
            <Collection />
        </div>
    )
}

export default page
