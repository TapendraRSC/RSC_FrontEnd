"use client"

import React from 'react'
import Users from '../components/Users/User'

const page = () => {
    return (
        <div>
            <Users />
        </div>
    )
}

export default page
